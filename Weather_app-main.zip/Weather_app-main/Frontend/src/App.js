import React, { useState } from 'react';
import './App.css';

function App() {
  const [city, setCity] = useState('');
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const getWeather = async () => {
    if (!city) {
      setError("Please enter a city name.");
      return;
    }

    setLoading(true);
    setError('');

    try {
      const res = await fetch(`http://localhost:8080/api/weather?city=${city}`);
      const data = await res.json();
      if (data.error) {
        setWeather(null);
        setError(data.error);
      } else {
        setWeather(data);
      }
    } catch (err) {
      setWeather(null);
      setError('Failed to fetch weather data.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="App">
      <h1>🌤 Real-Time Weather App</h1>

      <div className="input-container">
        <input
          type="text"
          value={city}
          onChange={(e) => setCity(e.target.value)}
          placeholder="Enter city"
        />
        <button onClick={getWeather}>Get Weather</button>
      </div>

      {loading && (
        <div className="loading">
          <div></div>
        </div>
      )}

      {error && <p className="error">{error}</p>}

      {weather && !weather.error && (
        <div className="weather-info">
          <h2>{weather.name}, {weather.sys.country}</h2>
          <p>🌡 Temperature: {weather.main.temp} °C</p>
          <p>🌥 Condition: {weather.weather[0].main}</p>
          <p>💧 Humidity: {weather.main.humidity}%</p>
          <p>🌬 Wind Speed: {weather.wind.speed} m/s</p>
        </div>
      )}
    </div>
  );
}

export default App;
